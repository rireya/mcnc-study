declare global {
    interface Window {
        bizMOB: Record<any, any>; // window에 포함될 전역 변수 declare
        forge: Record<any, any>; // window에 포함될 전역 변수 declare
    }

    /** 전역 Type 선언 */

    // Json Type
    type Json = { [key: string]: any };
}

export { };