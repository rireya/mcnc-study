<template>
    <ion-app>
        <ion-router-outlet />
    </ion-app>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { IonApp, IonRouterOutlet } from '@ionic/vue';
import Event from '@/bizMOB/Xross/Event';

onMounted(async () => {
    Event.setEvent('ready', init);
});

// App, Web initialization code here
const init = () => {
    console.log('App initialized');
};
</script>
