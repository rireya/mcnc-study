import { createStore } from 'vuex';
import ProjectSharedModule from './modules/ProjectSharedModule';


export default createStore({
    modules: {
        ProjectSharedModule
    },
});