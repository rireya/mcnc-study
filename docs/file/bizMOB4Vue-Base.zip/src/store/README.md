# src/store

- Store 활용 폴더

- 프로젝트 환경에 맞춰서 vuex 또는 pinia를 사용 (기본적으로 둘다 설치되어 있음)
  - pinia: https://pinia.vuejs.kr/
  - vuex: https://vuex.vuejs.org/

- store 저장시 localStorage 또는 sessionStorage에 자동 저장되길 원하는 경우 아래의 플러그인을 활용
  - pinia: https://prazdevs.github.io/pinia-plugin-persistedstate/
  - vuex: https://github.com/robinvdvleuten/vuex-persistedstate
