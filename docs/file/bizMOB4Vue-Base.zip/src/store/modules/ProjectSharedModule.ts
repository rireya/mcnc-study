export default {
    namespaced: true,
    state: {
        sample: 'SAMPLE'
    },
    getters: {
        sample: (state: any)  =>  {
            return state.sample;
        }
    },
    mutations: {
        setSample(state: any, sampleData: string) {
            state.sample = sampleData;
        }
    },
    actions: {
        setSampleData : ({ commit }: any, sampleData: string ) => {
            commit('setSample', sampleData);
        }
    },
};
