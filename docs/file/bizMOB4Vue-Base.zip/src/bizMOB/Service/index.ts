import { GlobalDataService } from './modules/GlobalDataService';
import LocaleService from './modules/LocaleService';



/** 전역 함수 */
export {
    GlobalDataService,
    LocaleService,
};