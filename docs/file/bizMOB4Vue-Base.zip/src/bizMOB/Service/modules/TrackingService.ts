const bizMOB: any = window.bizMOB;

/**
 * 화면 이동 추적시 사용할 서비스
 */
export default class TrackingService {
    /**
     * 화면 추적 호출 API
     */
    static track(arg: {
        _sTrcode: string,
        _oHttpHeader?: Record<any, any>,
        _oHeader?: Record<any, any>,
        _oBody?: Record<any, any>,
    }): Promise<void> {
        return new Promise((resolve, reject) => {
            // 네트워크 요청
            bizMOB.Network.requestTr({
                _sTrcode: arg._sTrcode,
                _oHttpHeader: arg._oHttpHeader || {},
                _oHeader: arg._oHeader || {},
                _oBody: arg._oBody || {},
                _bProgressEnable: false,
                _fCallback: (res: any)=> {
                    if (res.header.result) {
                        resolve(res);
                    }
                    else {
                        reject(res);
                    }
                }
            });
        });
    }
}