# src/locales

- i18n 다국어 관련 사전 폴더
- 언어 코드는 /public/bizMOB/bizMOB-locale.js 파일 참조