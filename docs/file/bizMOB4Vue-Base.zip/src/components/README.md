# src/components

- 프로젝트 내에서 사용될 공통 컴포넌트 폴더
- 이름 규칙상 첫 글자는 대문자로 입력해야 함. (Ex. McncInput)