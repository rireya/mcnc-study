# src/router

- 라우팅 광련 폴더
- open은 `router.push`와 `ionRouter.navigate` 전부 사용 가능.
- 뒤로가기는 `router.back`으로 통일
