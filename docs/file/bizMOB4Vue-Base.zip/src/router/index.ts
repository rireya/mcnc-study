import { createRouter, createWebHistory } from '@ionic/vue-router';
import Event from '@/bizMOB/Xross/Event';
import Device from '@/bizMOB/Xross/Device';

import readme from '@/router/routes/readme';

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes: [
    // Default Path 설정
        {
            path: '/',
            redirect: '/readme',
        },

        // 라우터 추가
        ...readme,

        // 비 선언 Path 처리
        {
            path: '/:pathMatch(.*)*',
            redirect: '/', // 선언되지 않은 Path릂 지정된 경로로 리다이렉트
        },
    ]
});

/**
 * 네비게이션 가드 설정
 * to: 이동할 url
 * from: 현재 url
 * next: to에서 지정한 url로 이동하기 위해 호출하는 함수
 */
router.beforeEach(async(to, from) => {
    return true; // 이동을 막기 위해선 false를 리턴
});

// 라우터 이동 후 이벤트 설정
router.afterEach((to, from) => {
    // bizMOB Backbutton Default Event Setup
    Device.isApp() && Event.setEvent('backbutton', () => router.back());
});

export default router;
