# src/shared

- 프로젝트 공용 폴더
- 프로젝트 내에서 사용되는 공통 함수 및 Class 등 프로젝트 환경에 맞춰서 폴더와 파일 구성
  Ex. bizMOB request 통신, router 페이지 이동, loading 컴포넌트 동작, alert 컴포넌트 동작, ... 등
