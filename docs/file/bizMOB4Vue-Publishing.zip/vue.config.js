const Webpack = require('webpack'); // webpack 라이브러리를 불러옵니다.
const PreloadWebpackPlugin = require('@vue/preload-webpack-plugin');

/** Vue Build 옵션 */
module.exports = {
    // 파일명 해싱 설정
    filenameHashing: false,

    // 웹용 배포시 rootPath 설정시 public 경로 지정
    publicPath: '/',

    // CSS 관련 옵션 설정
    css: {
        sourceMap: true, // CSS 소스맵 On
    },

    // 웹팩 설정
    configureWebpack: {
        // 웹팩 플러그인 설정
        plugins: [
            // Webpack DefinePlugin 설정
            new Webpack.DefinePlugin({
                __VUE_OPTIONS_API__: JSON.stringify(true), // 옵션 API 지원 ON/OFF
                __VUE_PROD_DEVTOOLS__: JSON.stringify(false), // 프로덕션 빌드에서 devtools 지원 ON/OFF
                __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: JSON.stringify(false), // hydration mismatch 오류의 디테일을 제공 ON/OFF
            }),

            // 필수 리소스 사전 로드
            new PreloadWebpackPlugin({
                rel: 'preload',
                include: 'initial', // 초기 청크에 포함된 리소스
                as(entry) {
                    // 폰트 지원
                    if (entry.endsWith('.woff') || entry.endsWith('.woff2') || entry.endsWith('.ttf') || entry.endsWith('.otf')) {
                        return 'font';
                    }
                    // 이미지 지원
                    else if (entry.endsWith('.png') || entry.endsWith('.jpg') || entry.endsWith('.jpeg') || entry.endsWith('.svg') || entry.endsWith('.gif')) {
                        return 'image';
                    }
                    // CSS 파일
                    else if (entry.endsWith('.css')) {
                        return 'style';
                    }
                    // 기본적으로는 스크립트로 처리
                    else {
                        return 'script';
                    }
                },
                fileBlacklist: [/\.map$/, /\.hot-update\.js$/] // 불필요한 파일 제외
            }),

            // 나중에 필요할 가능성이 있는 리소스 미리 가져오기
            new PreloadWebpackPlugin({
                rel: 'prefetch',
                include: 'asyncChunks' // 비동기 청크
            })
        ],
    }
};
