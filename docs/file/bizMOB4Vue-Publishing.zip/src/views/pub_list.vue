<!--
  (필수 작성) 퍼블리싱된 화면 링크용 목록 화면
  주소는 파일생성시 views/ 를 기준으로 파일의 실제 경로로 자동 생성됨
-->
<template>
    <div class="wrapper">
        <h1>bizMOB4 Publishing</h1>

        <table>
            <colgroup>
                <col style="width: 7%" />
                <col style="width: 9%" span="2" />
                <col style="width: 10%" />
                <col style="width: 12%" />
                <col style="width: 15%" />
                <col style="width: 7%" span="2" />
                <col />
            </colgroup>

            <thead>
                <tr>
                <th scope="col">Folder</th>
                <th scope="col">1 Depth</th>
                <th scope="col">2 Depth</th>
                <th scope="col">3 Depth</th>
                <th scope="col">4 Depth</th>
                <th scope="col">File name</th>
                <th scope="col">Commit</th>
                <th scope="col">Update</th>
                <th scope="col">memo</th>
                </tr>
            </thead>

            <tbody>
                <tr> <!-- Row -->
                    <td></td> <!-- Folder -->
                    <td>BaseView</td> <!-- 1 Depth -->
                    <td></td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="/BaseView" target="_blank">BaseView.vue</router-link></td> <!-- File name -->
                    <td class="date"></td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td></td> <!-- memo -->
                </tr>

                <tr class="line"><td colspan="9"></td></tr> <!-- Folder 나눔 줄 -->

                <tr> <!-- Row -->
                    <td><em class="num"></em>SAMPLE</td> <!-- Folder -->
                    <td>예시</td> <!-- 1 Depth -->
                    <td>Page Sample</td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="/SAMPLE/Page" target="_blank">Page.vue</router-link></td> <!-- File name -->
                    <td class="date">23-06-09</td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td>Page 예시</td> <!-- memo -->
                </tr>

                <tr> <!-- Row -->
                    <td><em class="num"></em></td> <!-- Folder -->
                    <td></td> <!-- 1 Depth -->
                    <td>Popup Sample</td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="/SAMPLE/Popup" target="_blank">Popup.vue</router-link></td> <!-- File name -->
                    <td class="date">23-06-09</td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td>Modal 등으로 사용가능한 Popup 예시</td> <!-- memo -->
                </tr>

                <tr> <!-- Row -->
                    <td><em class="num"></em></td> <!-- Folder -->
                    <td></td> <!-- 1 Depth -->
                    <td>Loading Sample</td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="/SAMPLE/Loading" target="_blank">Loading.vue</router-link></td> <!-- File name -->
                    <td class="date">23-06-09</td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td>Loading 프로그레스바 예시</td> <!-- memo -->
                </tr>

                <tr> <!-- Row -->
                    <td><em class="num"></em></td> <!-- Folder -->
                    <td></td> <!-- 1 Depth -->
                    <td>Ionic Alert Sample</td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="/SAMPLE/IonicAlert" target="_blank">IonicAlert.vue</router-link></td> <!-- File name -->
                    <td class="date">23-06-09</td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td>Ionic에서 제공되는 Alert 예시</td> <!-- memo -->
                </tr>

                <tr> <!-- Row -->
                    <td><em class="num"></em></td> <!-- Folder -->
                    <td></td> <!-- 1 Depth -->
                    <td>Ionic Toast Sample</td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="/SAMPLE/IonicToast" target="_blank">IonicToast.vue</router-link></td> <!-- File name -->
                    <td class="date">23-06-15</td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td>Ionic에서 제공되는 Toast 예시</td> <!-- memo -->
                </tr>

                <tr> <!-- Row -->
                    <td><em class="num"></em></td> <!-- Folder -->
                    <td></td> <!-- 1 Depth -->
                    <td>Ionic Loading Sample</td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="/SAMPLE/IonicLoading" target="_blank">IonicLoading.vue</router-link></td> <!-- File name -->
                    <td class="date">23-06-15</td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td>Ionic에서 제공되는 Loading 예시</td> <!-- memo -->
                </tr>

                <tr> <!-- Row -->
                    <td><em class="num"></em> </td> <!-- Folder -->
                    <td></td> <!-- 1 Depth -->
                    <td></td> <!-- 2 Depth -->
                    <td></td> <!-- 3 Depth -->
                    <td></td> <!-- 4 Depth -->
                    <td><router-link to="" target="_blank"></router-link></td> <!-- File name -->
                    <td class="date"></td> <!-- Commit -->
                    <td class="date"></td> <!-- Update -->
                    <td></td> <!-- memo -->
                </tr>

                <tr class="line"><td colspan="9"></td></tr> <!-- Folder 나눔 줄 -->
            </tbody>
        </table>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped lang="scss">
    .wrapper {height: 100%; background-color: #f5f6fa !important; overflow: auto; -webkit-user-select: inherit; user-select: inherit; -webkit-touch-callout: inherit;}
    #app > * {max-width: 100%;}
    .wrapper {padding: 10px;}
    h1, h2 {margin-bottom:20px; text-align:left;}
    h2 {margin-top:25px;}
    a {color:#1376c6;}

    table {background-color: #fff; border:1px solid #502314; counter-reset: num 0;}
    table thead th {height:30px; border:1px solid #502314;}
    table td {padding:5px; border:1px solid #502314;}
    .date {text-align:center;}
    .date + .date {color:#d72300;}
    .line td {padding:1px;}
    .line02 td {padding:30px; font-size:1.2rem !important; color:#fffcf8; background:#ef8c8c;}
    td:last-child {font-size:0.9em;}
    tbody tr:hover {background:#fffcf8;}
    .renew {font-weight: bold; background:#dde2e8;}
    .noti_box {margin:10px 0; padding: 20px; font-weight: 500; background:#fffcf8; border-radius: 20px;}

    .num {display:inline-block; min-width:14px; height:20px; margin-right:3px; padding:0 2px; font-size:.75rem; color:#3ab1fc; text-align:center; vertical-align:middle; line-height:20px; letter-spacing:-1px; background:#f0f0f0; border-radius:2px;}
    .num::before {counter-increment: num 1; content: counter(num); }
</style>
