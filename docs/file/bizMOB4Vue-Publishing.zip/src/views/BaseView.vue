<!-- 퍼블리싱 기본 화면 -->
<template>
    <ion-page>

        <!-- Ionic Header Tag -->
        <ion-header>
            <div>
                Header
            </div>
        </ion-header>

        <!-- Ionic Contents Tag -->
        <ion-content>
            <div>
                Contents
            </div>
        </ion-content>

        <!-- Ionic Footer Tag 영역 -->
        <ion-footer>
            <div>
                Footer
            </div>
        </ion-footer>

    </ion-page>
</template>

<script setup lang="ts">
// Composition API Styles
</script>

<style scoped lang="scss">
    // CSS Capsule
</style>