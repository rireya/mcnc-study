<!--
    Loading 프로그레스바 샘플
    - Submit Loading: API 통신등 화면 전체를 덮는 Loading
    - Content Loading: 화면 내의 일부 컨텐츠 영역에 대한 Loading
    - Scroll Loading: 목록에서 하단에 표시될 Loading
-->
<template>

    <!-- Submit Loading-->
    <div class="loading_wrap">
        <article class="page_loading"><strong>loading...</strong></article>
    </div>

    <ion-page>
        <ion-header>
        <h1>Loading Sample</h1>
        </ion-header>

        <ion-content>
        <ion-card>
            <!-- Content Loading -->
            <div class="cont_loading" style="height: 100px;"><span>loading...</span></div>
        </ion-card>

        <div>
            <ul>
            <li>Item 1</li>
            <li>Item 2</li>
            <li>Item 3</li>
            <li>Item 4</li>
            <li>Item 5</li>
            <li>Item 6</li>
            <li>Item 7</li>
            <li>Item 8</li>

            <!-- Scroll Loading -->
            <div class="scroll_loading show"><span>loading...</span></div>
            </ul>
        </div>
        </ion-content>

    </ion-page>
</template>

<style scoped lang="scss">
    // CSS Capsule
    li {padding: 12px}
    li:nth-child(even) { background-color: rgba(128, 128, 128, 0.5); }
</style>