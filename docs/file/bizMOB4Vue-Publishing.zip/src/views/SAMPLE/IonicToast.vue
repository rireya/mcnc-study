<!--
    기본적으로 사용할 수 있는 Ionic에서 제공하는 Toast 예시
    CSS Custom 가능하며, 커스텀시 Style을 확인할 수 있도록 작성된 예시 화면
    (Ionic Toast Doc: https://ionicframework.com/docs/api/toast)
-->
<template>
    <div class="flex_bot c_btn">
        <button variant="tonal" class="btn01" @click="toast1"><span>1.5초 Toast</span></button>
        <button variant="tonal" class="btn01" @click="toast2"><span>10분 Toast</span></button>
    </div>
</template>

<script setup lang="ts">
import { toastController } from '@ionic/vue';

const toast1 = async () => {
    const toast = await toastController.create({
        message: '1.5초 toast',
        duration: 1500,
        position: 'bottom'
    });

    await toast.present();
}

const toast2 = async () => {
    const toast = await toastController.create({
        message: '10분 Toast',
        duration: 600000,
        position: 'bottom'
    });

    await toast.present();
};
</script>

<style scoped lang="scss">
  // CSS Capsule
</style>