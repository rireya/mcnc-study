<!--
    기본적으로 사용할 수 있는 Ionic에서 제공하는 Alert 예시
    CSS Custom 가능하며, 커스텀시 Style을 확인할 수 있도록 작성된 예시 화면
    (Ionic Loading Doc: https://ionicframework.com/docs/api/alert)
-->
<template>
    <div class="flex_bot c_btn">
        <button variant="tonal" class="btn01" @click="presentAlert"><span>Alert</span></button>
        <button variant="tonal" class="btn01" @click="presentConfirm"><span>Confirm</span></button>
    </div>
</template>

<script setup lang="ts">
import { alertController } from '@ionic/vue';

/** 버튼 한개 Alert */
const presentAlert = async () => {
    const alert = await alertController.create({
        header: 'Alert',
        subHeader: 'Important message',
        message: 'This is an alert!',
        buttons: ['OK'],
    });

    await alert.present();
};

/** 버튼 2개 Confirm + 버튼 handler */
const presentConfirm =async () => {
    const buttons = [{
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
            console.log('Confirm Cancel');
        }
    }, {
        text: 'OK',
        role: 'confirm',
        handler: () => {
            console.log('Confirm OK');
        }
    }];
    const confirm = await alertController.create({
        header: 'Confirm',
        subHeader: 'Important message',
        message: 'This is an confirm!',
        buttons: buttons,
    });

    await confirm.present();
};
</script>