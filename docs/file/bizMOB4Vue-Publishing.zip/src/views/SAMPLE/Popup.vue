<template>
    <div class="modalWrap">
        <article class="popWrap">
        <header class="pop_head">
            <h1 class="pop_tit">Modal Title</h1>
            <button type="button" class="btn_pop_close"><span>Close</span></button>
        </header>

        <div class="pop_cont">
            <p>Modal Sample</p>
        </div>

        <footer class="pop_foot">
            <button type="button"><span>확인</span></button>
        </footer>
        </article>
    </div>
</template>