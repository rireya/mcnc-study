<template>
    <ion-page class="bg_w">

        <!-- header -->
        <ion-header class="headerWrap">
        <div class="titleBar">
            <div class="title_btn right">
            <button type="button" class="btn_head_close"><span>Close page</span></button>
            </div>
        </div>
        </ion-header>

        <!-- contents area -->
        <ion-content class="contentsWrap">
        <div class="web_container m_dflex">
            <div class="flex_cont">
            <div class="form_container">
                <h1 class="tit_lg">약관 동의</h1>

                <div class="agree_intro_text cen">
                <p>약관 동의 후 본인인증을 진행해주세요.</p>
                </div>

                <h2 class="tit01">닉네임 설정</h2>
                <div class="inp_box">
                <div class="inp"><input type="text" id="" placeholder="닉네임(한글 최대 5자 / 영문 7자)" /></div>
                <button type="button" class="btn_inp_del"><span>Delete input text</span></button>
                </div>

                <div class="cen">
                <img src="@/assets/images/bizMOB.png" /> <!-- HTML 이미지 경로 예시 -->
                </div>
            </div>
            </div>
        </div>
        </ion-content>

        <!-- footer -->
        <ion-footer>
        <div class="flex_bot c_btn">
            <button variant="tonal" class="btn01 cancel"><span>취소</span></button>
            <button variant="tonal" class="btn01"><span>확인</span></button>
        </div>
        </ion-footer>

    </ion-page>
</template>