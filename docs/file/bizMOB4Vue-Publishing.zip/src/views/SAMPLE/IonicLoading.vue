<!--
    기본적으로 사용할 수 있는 Ionic에서 제공하는 Loading 예시
    CSS Custom 가능하며, 커스텀시 Style을 확인할 수 있도록 작성된 예시 화면
        * 주의!: 완전한 Custom은 힘들기 때문에 프로젝트별 Loading 커스텀이 필요한 경우 Loading.vue 예시를 참조
    (Ionic Loading Doc: https://ionicframework.com/docs/api/loading)
-->
<template>
    <div class="flex_bot c_btn">
        <button variant="tonal" class="btn01" @click="loading1"><span>1초 Loading</span></button>
        <button variant="tonal" class="btn01" @click="loading2"><span>10분 Loading</span></button>
    </div>
</template>

<script setup lang="ts">
import { loadingController } from '@ionic/vue';

const loading1 = async () => {
    const loading = await loadingController.create({
        message: 'Loading...',
    });

    loading.present();

    setTimeout(() => {
        loading.dismiss();
    }, 1000);
}

const loading2 = async () => {
    const loading = await loadingController.create({
        message: 'Loading...',
    });

    loading.present();

    setTimeout(() => {
        loading.dismiss();
    }, 600000);
}
</script>

<style scoped lang="scss">
  // CSS Capsule
</style>