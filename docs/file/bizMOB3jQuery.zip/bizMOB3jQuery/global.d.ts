interface Object {
    values: (o: object) => Array;
    entries: (o: object) => Array;
}

interface Array {
    includes: (a: any, n?: number) => boolean;
}

interface Element {
    observer: (f: function, o: object) => void;
}

interface Date {
    getDayName: (b: boolean) => string;
    getWeek: (n: number) => number;
    toFormat: (s: string) => string;
    toDate: (n: number) => Date;
}

interface String {
    padStart: (n: number, s: string | number) => string;
    padEnd: (n: number, s: string | number) => string;
}

declare var jQuery: any;
declare var $: any;
declare var bizMOBCore: any;
declare var bizMOB: any;

declare type bizMobRoot = any;