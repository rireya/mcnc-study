const bizMOB: any = window.bizMOB;

export default class Config {
    /** 연락처 조회 */
    static set(target: string, className: string, arg: any) {
        bizMOB.setConfig(target, className, arg);
    }

    /** 연락처 조회 */
    static get(target: string, className: string) {
        bizMOB.getConfig(target, className);
    }
}