import { createStore } from 'vuex';
import GlobalSharedModule from './modules/GlobalSharedModule';

export default createStore({
    modules: {
        GlobalSharedModule,
    },
});