interface IGlobalData {
  key: string;
  value: any;
}

export default {
    namespaced: true,
    state: {
        DATAS : {}
    },
    getters: {
        getDataByKey: (state: any) => (key: string) =>  {
            return state.DATAS[key];
        },
    },
    mutations: {
        setData(state:any, data: IGlobalData) {
            state.DATAS[data.key] = data.value;
        },
        removeData(state: any, key: string) {
            delete state.DATAS[key];
        },
    },
    actions: {
    // 공유 데이터 Set
        setSharedData: ({ commit }: any, data: IGlobalData ) => {
            commit('setData', data);
        },
        // 공유 데이터 Remove
        removeSharedData: ({ commit }: any, key: string ) => {
            commit('removeData', key);
        },
    },
};
