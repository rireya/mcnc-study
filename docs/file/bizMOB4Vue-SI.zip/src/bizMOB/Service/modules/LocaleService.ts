import Network from '@/bizMOB/Xross/Network';
import Localization from '@/bizMOB/Xross/Localization';
import i18n from '@/bizMOB/i18n';

export default class LocaleService {
    async initLocale() {
        const res = await Localization.getLocale();

        if (res.locale !== '') {
            i18n.global.locale.value = res.locale.substring(0,2);
            Network.changeLocale({ _sLocaleCd: res.locale });
        }
    }

    async getLocale() {
        return Localization.getLocale();
    }

    changeLocale(newLocaleCd: string){
        Network.changeLocale({ _sLocaleCd: newLocaleCd });
        Localization.setLocale({ _sLocaleCd: newLocaleCd });
    }
}