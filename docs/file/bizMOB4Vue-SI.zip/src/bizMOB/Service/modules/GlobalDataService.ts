import bizMOBStore from '@/bizMOB/Store';

export function GlobalDataService() {
    return {
        getGlobalDataByKey: (key: string) => {
            return bizMOBStore.getters['GlobalSharedModule/getDataByKey'](key);
        },
        setGlobalDataByKey: (key: string, value: any) => {
            bizMOBStore.dispatch('GlobalSharedModule/setSharedData', { key: key,  value: value});
        },
        removeGlobalDataByKey: (key: string) => {
            bizMOBStore.dispatch('GlobalSharedModule/removeSharedData',key );
        }
    };
}