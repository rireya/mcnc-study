import { encode } from 'url-safe-base64';

const bizMOB: any = window.bizMOB;
const forge: any = window.forge;

/**
키 공유 전문(BM4001)
    BM4001IMPL0001
        서버에서 암호화 키 생성 과정에서 오류 발생(요청 cryPbKey 값이 잘못 되었거나, 서버 오류)
    서버 로그 확인 필요

토큰 갱신 전문(BM4002)
    BM4002TKER1001
        유효하지 않은 토큰 (bizMOB Server에서 생성된 토큰이 아닐 경우, 일반적인 상황에서는 발생 안됨)
    BM4002TKER1002
        Refresh token 이 만료 되었을 경우 발생
    키공유전문(BM4001) 다시 호출하여 신규 암호화키, 토큰 발행

전문 호출
    EAH000
        서버의 세션이 만료
        키공유전문(BM4001) 다시 호출하여 신규 암호화키, 토큰 발행
    EAH001
        암호화 인증 토큰 만료(cryAuthToken)
        토큰갱신전문(BM4002) 호출하여 암호화 인증 토큰 갱신
    {TRCODE}CRPTEDC001
        서버에서 전문 복호화 시 오류 발생
        암호화 된 전문과 암호화 키가 일치 하지 않을 경우 발생 (일반적인 상황에서 발생 안됨)
*/

export default class BzCrypto {
    private static cryAuthToken: string;
    private static cryRefreshToken: string;
    private static cryAuthTokenExpTime: string;

    private static replaceStr1 = '-----BEGIN PUBLIC KEY-----';
    private static replaceStr2 = '-----END PUBLIC KEY-----';

    /** Auth Token 발급 */
    static shareAuthKey(arg: {
        _bProgressEnable?: boolean; // Native App Progress 사용 여부
    }): Promise<void> {
        return new Promise((resolve, reject) => {
            const keys = forge.pki.rsa.generateKeyPair(512);
            const privateKey = keys.privateKey;
            const publicKey = keys.publicKey;
            const publicPem = forge.pki
                .publicKeyToPem(publicKey)
                .replace(BzCrypto.replaceStr1, '')
                .replace(BzCrypto.replaceStr2, '')
                .replace(/(\r\n|\n|\r)/gm, '');

            bizMOB.Network.requestTr({
                _sTrcode: 'BM4001',
                _oBody: {
                    cryPbKey: encode(publicPem)
                },
                _bProgressEnable: arg._bProgressEnable ?? false,
                _fCallback: (res: any)=> {
                    if (res. header.result) {
                        BzCrypto.cryAuthToken = res.body.cryAuthToken;
                        BzCrypto.cryRefreshToken = res.body.cryRefreshToken;
                        BzCrypto.cryAuthTokenExpTime = res.body.cryAuthTokenExpTime;

                        const crySymKey = res.body.crySymKey;
                        const decode64 = forge.util.decode64(crySymKey);
                        const decrypt = privateKey.decrypt(decode64);
                        const decodeUtf8 = forge.util.decodeUtf8(decrypt);

                        bizMOB.setConfig('WEB', 'Network', {
                            _sCryAuthToken: BzCrypto.cryAuthToken,
                            _sCrySymKey: decodeUtf8,
                        });

                        resolve();
                    }
                    else {
                        BzCrypto.cryAuthToken = '';
                        BzCrypto.cryRefreshToken = '';
                        BzCrypto.cryAuthTokenExpTime = '';

                        bizMOB.setConfig('WEB', 'Network', {
                            _sCryAuthToken: '',
                            _sCrySymKey: '',
                        });

                        reject(res.header.error_code);
                    }
                }
            });
        });
    }

    /** Auth Token 갱신 */
    static renewAuthToken(arg: {
        _bProgressEnable?: boolean; // Native App Progress 사용 여부
    }): Promise<void> {
        return new Promise((resolve, reject) => {
            bizMOB.Network.requestTr({
                _sTrcode: 'BM4002',
                _oBody: {
                    cryAuthToken: BzCrypto.cryAuthToken,
                    cryRefreshToken: BzCrypto.cryRefreshToken
                },
                _bProgressEnable: arg._bProgressEnable ?? false,
                _fCallback: (res:any)=> {
                    if (res.header.result) {
                        BzCrypto.cryAuthToken = res.body.cryAuthToken;
                        BzCrypto.cryRefreshToken = res.body.cryRefreshToken;
                        BzCrypto.cryAuthTokenExpTime = res.body.cryAuthTokenExpTime;

                        bizMOB.setConfig('WEB', 'Network', {
                            _sCryAuthToken: BzCrypto.cryAuthToken,
                        });

                        resolve();
                    }
                    else {
                        BzCrypto.cryAuthToken = '';
                        BzCrypto.cryRefreshToken = '';
                        BzCrypto.cryAuthTokenExpTime = '';

                        bizMOB.setConfig('WEB', 'Network', {
                            _sCryAuthToken: '',
                        });

                        reject(res.header.error_code);
                    }
                }
            });
        });
    }

    /** Auth Token 발급 여부 */
    static isToken(): boolean {
        return !!BzCrypto.cryAuthToken;
    }

    /** Auth Token 갱신필요 여부 */
    static isExpiredToken(): boolean {
        const expTime = new Date(BzCrypto.cryAuthTokenExpTime + 'Z'); // 'Z'를 추가하여 UTC로 파싱하도록 함
        const nowTime = new Date(); // 현재 시간 (로컬 타임존 기준)

        return !!BzCrypto.cryRefreshToken && (nowTime > expTime); // 현재 시간이 주어진 시간보다 이후인지 비교
    }
}