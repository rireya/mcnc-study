import { createStore, createLogger } from 'vuex';
import createPersistedState from 'vuex-persistedstate';

import app from './modules/app';
import login from './modules/login';
import user from './modules/user';

// persistedstate custom storage
const customStorage = (storage: any) => {
    const getKey = (prefix: string, path: string) => `${prefix}::${path}`;
    const getPrefix = (prefix: string) => `${prefix}::`;
    const getPath = (key: string) => key.split('::')[1];

    return {
        getItem: () => {
            const json: any = {};
            for (const path in storage) {
                if (Object.prototype.hasOwnProperty.call(storage, path)) {
                    const value = storage[path];
                    try {
                        json[getPath(path)] = JSON.parse(value);
                    } catch (error) {
                        json[getPath(path)] = value;
                    }
                }
            }

            return json;
        },
        setItem: (key: string, value: string) => {
            const object = JSON.parse(value);
            for (const path in object) {
                if (Object.prototype.hasOwnProperty.call(object, path)) {
                    const state = object[path];
                    try {
                        storage.setItem(getKey(key, path), JSON.stringify(state));
                    } catch (error) {
                        storage.setItem(getKey(key, path), state);
                    }
                }
            }
        },
        removeItem: (key: string) => {
            for (const path in storage) {
                if (Object.prototype.hasOwnProperty.call(storage, path)) {
                    if (path.includes(getPrefix(key))) {
                        storage.removeItem(path);
                    }
                }
            }
        }
    };
};

export default createStore({
    modules: {
        app,
        login,
        user,
    },
    strict: process.env.NODE_ENV !== 'production',
    plugins: [
        ...(
            process.env.NODE_ENV !== 'production'
                ? [ createLogger() ]
                : []
        ),
        createPersistedState({
            key: 'APP', // prefix key
            paths: ['user'], // sessionStorage에 저장할 모듈명
            storage: customStorage(sessionStorage),
        }),
        createPersistedState({
            key: 'APP', // prefix key
            paths: ['login'], // localStorage에 저장할 모듈명
            storage: customStorage(localStorage),
        })
    ]
});