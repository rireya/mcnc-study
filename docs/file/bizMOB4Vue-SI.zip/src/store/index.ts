import { createStore, createLogger } from 'vuex';
import createPersistedState from 'vuex-persistedstate';

import app from './modules/app';
import login from './modules/login';
import user from './modules/user';

const customStorage = (storage: any) => {
    // 키를 생성하는 함수: prefix와 path를 결합하여 고유 키를 생성합니다.
    const getKey = (prefix: string, path: string) => `${prefix}::${path}`;

    // prefix를 생성하는 함수: prefix에 "::"를 붙여서 반환합니다.
    const getPrefix = (prefix: string) => `${prefix}::`;

    // 경로를 얻는 함수: "::"로 구분된 키에서 두 번째 부분을 반환합니다.
    const getPath = (key: string) => key.split('::')[1];

    return {
        // 저장소에서 모든 항목을 가져오는 함수
        getItem: () => {
            const json: any = {};
            for (const path in storage) {
                if (Object.prototype.hasOwnProperty.call(storage, path)) {
                    const value = storage[path];
                    try {
                        // JSON 형식으로 변환할 수 있으면 변환해서 저장
                        json[getPath(path)] = JSON.parse(value);
                    } catch (error) {
                        // JSON 형식이 아니면 그대로 저장
                        json[getPath(path)] = value;
                    }
                }
            }

            return json;
        },
        // 항목을 저장소에 설정하는 함수
        setItem: (key: string, value: string) => {
            const object = JSON.parse(value);
            for (const path in object) {
                if (Object.prototype.hasOwnProperty.call(object, path)) {
                    const state = object[path];
                    try {
                        // 객체를 JSON 형식으로 저장
                        storage.setItem(getKey(key, path), JSON.stringify(state));
                    } catch (error) {
                        // JSON 형식으로 변환할 수 없으면 그대로 저장
                        storage.setItem(getKey(key, path), state);
                    }
                }
            }
        },
        // 특정 키를 포함하는 항목을 저장소에서 제거하는 함수
        removeItem: (key: string) => {
            for (const path in storage) {
                if (Object.prototype.hasOwnProperty.call(storage, path)) {
                    // 특정 키가 포함된 항목을 찾아서 제거
                    if (path.includes(getPrefix(key))) {
                        storage.removeItem(path);
                    }
                }
            }
        }
    };
};

export default createStore({
    modules: {
        app,
        login,
        user,
    },
    strict: process.env.NODE_ENV !== 'production',
    plugins: [
        ...(
            process.env.NODE_ENV !== 'production'
                ? [ createLogger() ]
                : []
        ),
        createPersistedState({
            key: 'APP', // prefix key
            paths: ['user'], // sessionStorage에 저장할 모듈명
            storage: customStorage(sessionStorage),
        }),
        createPersistedState({
            key: 'APP', // prefix key
            paths: ['login'], // localStorage에 저장할 모듈명
            storage: customStorage(localStorage),
        })
    ]
});