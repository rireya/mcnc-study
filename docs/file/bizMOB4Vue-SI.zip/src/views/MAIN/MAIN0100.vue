<template>
    <ion-page>
        <!-- Ionic Header Tag -->
        <ion-header>
            <AppHeader
                title="메인"
                :rightButtons="['menu']"
            />
        </ion-header>

        <!-- Ionic Contents Tag -->
        <ion-content>
            <div class="button-group column">
                <button id="open-modal" class="button button-line" @click="openPage('BOARD0100')">Board Open</button>
                <button id="open-modal" class="button button-line" @click="openPage('MAIN0200')">Sandbox Open</button>
            </div>
        </ion-content>
    </ion-page>
</template>

<script setup lang="ts">
import { useNavigate, useModal } from '@/shared';

import BOARD0200 from '@/views/BOARD/BOARD0200.vue';

const { openPage } = useNavigate();
const { openModal } = useModal();

const onOpenModal = () => {
    openModal(BOARD0200, {
        option: {
            css: ['modal-height-80vh']
        }
    });
};
</script>

<style scoped lang="scss">
.button-group {
    padding: 0 16px 24px;
}
</style>
