<template>
    <ion-page>
        <!-- Ionic Header Tag -->
        <ion-header>
            <AppHeader
                title="메인"
                :rightButtons="['menu']"
            />
        </ion-header>

        <!-- Ionic Contents Tag -->
        <ion-content>
            <div class="button-group column">
                <button id="open-modal" class="button button-line" @click="openPage('BOARD0100')">Board Open</button>
                <button id="open-modal" class="button button-line" @click="openPage('MAIN0200')">Sandbox Open</button>
            </div>
        </ion-content>
    </ion-page>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { onIonViewWillEnter, onIonViewDidEnter, onIonViewWillLeave, onIonViewDidLeave } from '@ionic/vue';
import { useNavigate } from '@/shared';

const { openPage } = useNavigate();

// 페이지 Enter 1
onIonViewWillEnter(() => {
    console.log('ionViewWillEnter');
});

// 페이지 Enter 2
onMounted(() => {
    console.log('mounted');
});

// 페이지 Enter 3
onIonViewDidEnter(() => {
    console.log('ionViewDidEnter');
});


// 페이지 Leave 1
onIonViewWillLeave(() => {
    console.log('ionViewWillLeave');
});

// 페이지 Leave 2
onIonViewDidLeave(() => {
    console.log('ionViewDidLeave');
});
</script>

<style scoped lang="scss">
.button-group {
    padding: 0 16px 24px;
}
</style>
