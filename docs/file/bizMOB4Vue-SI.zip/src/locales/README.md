# src/locales

- i18n 다국어 관련 사전 폴더
