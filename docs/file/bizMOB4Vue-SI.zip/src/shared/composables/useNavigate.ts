import { computed } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { useIonRouter, menuController } from '@ionic/vue';
import { StoreService } from '@/shared';
import app from '@/store/modules/app';

/**
 * @title Navigate Composable
 * @description 화면 제어와 연관된 공통함수
 */
export function useNavigate() {
    const ionRouter = useIonRouter();
    const route = useRoute();
    const router = useRouter();

    function getLocation(name: string, params?: any) {
        const location: any = {};

        // name이 '/'로 시작하면 path로 인식
        if (name.indexOf('/') === 0) {
            location['path'] = name;
        }
        else {
            location['name'] = name;
        }

        if (params) {
            location['query'] = params;
        }

        return location;
    }

    return {
        // 실시간 hash를 반환하는 함수
        getHashComp: () => {
            return computed(() => route.hash);
        },

        // 실시간 props를 반환하는 함수
        getPropsComp: (def: Record<any, any>) => {
            return computed(() => ({ ...def, ...route.params, ...route.query }));
        },

        // 화면 오픈 (to는 path 또는 name)
        openPage: (to: string | Json, params?: Json, isAnimation = true): void => {
            const appStore = new StoreService('app');
            appStore.dispatch('setRouteNext', true);

            const location = (typeof  to === 'string') ? getLocation(to, params) : to;
            ionRouter.navigate(location, isAnimation ? 'forward' : 'none', 'push');
        },

        // 화면 교체 (to는 path 또는 name)
        replacePage: (to: string | Json, params?: Json, isAnimation = true): void => {
            const appStore = new StoreService('app');
            appStore.dispatch('setRouteNext', true);

            const location = (typeof  to === 'string') ? getLocation(to, params) : to;
            ionRouter.navigate(location, isAnimation ? 'forward' : 'none', 'replace');
        },

        // 화면 닫기
        back: (): void => {
            router.back();
        },

        // 메뉴 열기
        openMenu: (): void => {
            const appStore = new StoreService('app');
            appStore.dispatch('openMenu');
        },

        // 메뉴 닫기
        closeMenu: async (): Promise<boolean> => {
            return await menuController.close();
        }
    };
}