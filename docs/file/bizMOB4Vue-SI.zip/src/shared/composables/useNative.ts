/**
 * @title Native Composable
 * @description Native 추가 플러그인 제어와 연관된 공통함수
 */
export function useNative() {
    return {
        // TODO
    };
}