export enum CONST {
    FOO = 'foo',
    BAR = 'bar',
}

export const ROW_NUM = 10;