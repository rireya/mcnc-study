import { createRouter, createWebHistory } from '@ionic/vue-router';
import { alertController, modalController, menuController } from '@ionic/vue';
import { StoreService, useMessage } from '@/shared';
import App from '@/bizMOB/Xross/App';
import Event from '@/bizMOB/Xross/Event';
import Device from '@/bizMOB/Xross/Device';

import readme from '@/router/routes/readme';

/** Sample */
import loginRoutes  from '@/router/routes/login';
import boardRoutes from '@/router/routes/board';
import mainRoutes from '@/router/routes/main';

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes: [
    // Default Path 설정
        {
            path: '/',
            redirect: '/login',
        },

        // 라우터 추가
        ...readme,

        // Sample
        ...loginRoutes,
        ...mainRoutes,
        ...boardRoutes,

        // 비 선언 Path 처리
        {
            path: '/:pathMatch(.*)*',
            redirect: '/', // 선언되지 않은 Path릂 지정된 경로로 리다이렉트
        },
    ]
});

/**
 * 네비게이션 가드 설정
 * to: 이동할 url
 * from: 현재 url
 * next: to에서 지정한 url로 이동하기 위해 호출하는 함수
 */
let isAppKillDelay = false;
router.beforeEach(async(to, from) => {
    const { toast } = useMessage();
    const appStore = new StoreService('app');
    const isRouteNext = appStore.getters('isRouteNext');

    // Root 화면
    if (from.path === '/') {
        appStore.dispatch('setRouteNext', false);
        return true;
    }
    // 화면 Open 여부
    else if (isRouteNext) {
        appStore.dispatch('setRouteNext', false);
        return true;
    }
    // 뒤로가기
    else {
        // TODO - 뒤로가기시 url 변경된 후 다시 돌아옴. 속도 개선 필요. next 파라미터 추가한 후에 overlay시 next(false)를 먼저 처리후 overlay를 닫으면 안느껴짐
        const isMenuOpen = document.querySelector('ion-app > ion-menu.show-menu'); // 메뉴 Open 여부
        const isAlert = document.querySelectorAll('ion-app > ion-alert').length > 0; // alert 존재 여부
        const isSelect = document.querySelectorAll('ion-app > ion-modal.ion-select-wrapper').length > 0; // select 존재 여부
        const isSheet = document.querySelectorAll('ion-app > ion-modal.ion-sheet-wrapper').length > 0; // modal 존재 여부
        const isModal = document.querySelectorAll('ion-app > ion-modal.ion-modal-wrapper').length > 0; // modal 존재 여부
        const isPopup = document.querySelectorAll('ion-app > ion-modal.ion-popup-wrapper').length > 0; // popup 존재 여부
        const isBackPrevent = document.querySelectorAll('ion-app > .backbutton-prevent').length > 0; // modal 물리 backbutton 막기 여부

        // Alert이 있는 경우 뒤로가기 버튼 막음
        if (isAlert) {
            return false; // 이동을 막기 위해선 false를 리턴
        }
        // 메뉴가 Open 되어 있는 경우
        else if (isMenuOpen) {
            await menuController.close();
            return false;
        }
        // Modal Type 중 Select가 있는 경우 Select 닫기
        else if (isSelect) {
            if (!isBackPrevent) {
                await modalController.dismiss(null, 'cancel'); // Modal 닫기
            }
            return false; // 이동을 막기 위해선 false를 리턴
        }
        // Modal Type 중 Sheet가 있는 경우 Sheet 닫기
        else if (isSheet) {
            if (!isBackPrevent) {
                await modalController.dismiss(null, 'cancel'); // Modal 닫기
            }
            return false; // 이동을 막기 위해선 false를 리턴
        }
        // Modal Type 중 Modal이 있는 경우 Modal 닫기
        else if (isModal) {
            if (!isBackPrevent) {
                await modalController.dismiss(null, 'cancel'); // Modal 닫기
            }
            return false; // 이동을 막기 위해선 false를 리턴
        }
        // Modal Type 중 Popup이 있는 경우 Popup 닫기
        else if (isPopup) {
            if (!isBackPrevent) {
                await modalController.dismiss(null, 'cancel'); // Modal 닫기
            }
            return false; // 이동을 막기 위해선 false를 리턴
        }
        // 메인 화면인 경우 뒤로가기 버튼을 누르면 앱 종료
        else if (from.path === '/main') {
            if (isAppKillDelay) {
                App.exit({ _sType: 'kill' });
            }
            else {
                toast('앱을 종료하시려면 한번 더 뒤로가기 버튼을 눌러주세요.');
                isAppKillDelay = true;

                setTimeout(() => isAppKillDelay = false, 1500);
                return false;
            }
        }
        // 그 외
        else {
            return true;
        }
    }
});

// 라우터 이동 후 이벤트 설정
router.afterEach((to, from) => {
    // bizMOB Backbutton Default Event Setup
    Device.isApp() && Event.setEvent('backbutton', () => router.back());
});

export default router;
