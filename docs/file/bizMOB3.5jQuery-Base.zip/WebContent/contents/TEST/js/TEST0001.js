/**
 * @author author
 * @pages [ TEST0001 ]
 * @title TEST0001
 * @type {any}
 */

/** @type {bizMobRoot} */
var page = {
    init: function(event) {
        console.log(event);
        page.test();
    },

    test: function() {
        return "TEST";
    },

    call1: function() {

    }
};