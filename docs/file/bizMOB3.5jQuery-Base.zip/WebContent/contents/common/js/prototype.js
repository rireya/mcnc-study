/**
 * Element 옵져버 함수
 * @param {function} callback - intersection callback 함수
 * @param {object} _option - 설정 옵션
 */
Element.prototype.observer = function(callback, _option) {
    var option = _option || {};

    var observer = new IntersectionObserver(function(entries, observer) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                // 인터렉션 발생시 옵져버 종료
                observer.unobserve(this);

                // handler 객체 전달
                callback({
                    observer: observer,
                    entry: entry,
                    element: this,
                    on: function() {
                        observer.observe(this);
                    },
                    off: function() {
                        observer.unobserve(this);
                    },
                    hide: function() {
                        this.style.display = "none";
                    }
                });
            }
        });
    }, {
        root: null,
        threshold: 0.0,
        rootMargin: "0px 0px " + (option.margin || 0) + "px"
    });

    observer.observe(this);
};

/**
 * Date의 요일명 조회
 * @param {boolean} [isLong] - 요일명 전체 조회 여부
 */
Date.prototype.getDayName = function(isLong) {
    var shortNames = [ "일", "월", "화", "수", "목", "금", "토" ];
    var longNames = [ "일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일" ];
    var day = this.getDay();

    return isLong ? longNames[day] : shortNames[day];
};

/**
 * Date 주차 조회
 * @param {number} [_dowOffset=1] - 기준 요일 (Default 월요일)
 * @returns number
 */
Date.prototype.getWeek = function(_dowOffset) {
    var dowOffset = typeof _dowOffset === "number" ? _dowOffset : 1; // 기본 월요일 시작
    var newYear = new Date(this.getFullYear(),0,1);
    var day = newYear.getDay() - dowOffset; //the day of week the year begins on
    day = (day >= 0 ? day : day + 7);
    var dayNum = Math.floor((this.getTime() - newYear.getTime() -
    (this.getTimezoneOffset()-newYear.getTimezoneOffset())*60000)/86400000) + 1;
    var weekNum;
    //if the year starts before the middle of a week
    if (day < 4) {
        weekNum = Math.floor((dayNum+day-1)/7) + 1;
        if (weekNum > 52) {
            var nYear = new Date(this.getFullYear() + 1,0,1);
            var nday = nYear.getDay() - dowOffset;
            nday = nday >= 0 ? nday : nday + 7;
            /*if the next year starts before the middle of
            the week, it is week #1 of that year*/
            weekNum = nday < 4 ? 1 : 53;
        }
    }
    else {
        weekNum = Math.floor((dayNum+day-1)/7);
    }
    return weekNum;
};

/**
 * Date 날짜 포맷 변경
 * @param {string} f - 변경할 포맷
 * @returns string
 */
Date.prototype.toFormat = function(f) {
    if (!this.valueOf()) { return ""; }

    var weekNameShort = [ "일", "월", "화", "수", "목", "금", "토" ];
    var weekNameLong = [ "일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일" ];
    var d = this;

    return f.replace(/(YYYY|YY|MM|DD|ee|EE|hh|aph|mm|ss|a\/p)/g, function($1) {
        switch ($1) {
            case "YYYY": return String(d.getFullYear());
            case "YY": return String(d.getFullYear() % 1000).padStart(2, 0);
            case "MM": return String(d.getMonth() + 1).padStart(2, 0);
            case "DD": return String(d.getDate()).padStart(2, 0);
            case "EE": return weekNameLong[d.getDay()];
            case "ee": return weekNameShort[d.getDay()];
            case "hh": return String(d.getHours()).padStart(2, 0);
            case "aph": return String(( d.getHours() % 12 ) ? d.getHours() % 12 : 12).padStart(2, 0);
            case "mm": return String(d.getMinutes()).padStart(2, 0);
            case "ss": return String(d.getSeconds()).padStart(2, 0);
            case "a/p": return d.getHours() < 12 ? "오전" : "오후";
            default: return $1;
        }
    });
};

/**
 * Date 날짜 바꿔서 반환
 * @param {number | string} _date - 변경할 일자
 * @returns
 */
Date.prototype.toDate = function(_date) {
    var date = new Date(this);
    return new Date(date.setDate(Number(_date)));
};

/**
 * Date 주간 데이터로 바꿔서 반환
 * @param {number} [_dowOffset=1] - 기준 요일 (Default 월요일)
 * @returns number
 */
Date.prototype.toWeek = function(_dowOffset) {
    if (!this.valueOf()) { return []; }

    var dowOffset = typeof _dowOffset === "number" ? _dowOffset : 1;
    var date = this.getDate();
    var day = this.getDay() - dowOffset;
    var startDate = new Date(this);
    var endDate = new Date(this);

    day = (day >= 0 ? day : day + 7);

    startDate.setDate(date - day);
    endDate.setDate(date + 6 - day);

    return [ startDate, endDate ];
};

// Date 월 데이터로 변경
Object.defineProperty(Date.prototype, "toMonth", {
    value: function() {
        if (!this.valueOf()) { return null; }

        return new Date(this.getFullYear(), this.getMonth());
    }
});

// Date 일 추가
Object.defineProperty(Date.prototype, "addDays", {
    value: function(value) {
        var date = new Date(this);

        return new Date(date.setDate(date.getDate() + (value || 1 )));
    }
});

// Date 월 추가
Object.defineProperty(Date.prototype, "addMonths", {
    value: function(value) {
        var date = new Date(this);
        var days = date.getDate();

        date.setMonth(date.getMonth() + value);

        // 31일에 한달을 더한 경우 2개월이 더해져서 분기처리
        if (date.getDate() != days) {
            date.setDate(0);
        }

        return date;
    }
});

// Date 년 추가
Object.defineProperty(Date.prototype, "addYears", {
    value: function(value) {
        var date = new Date(this);

        return new Date(date.setFullYear(date.getFullYear() + (value || 1)));
    }
});

// Date 해당 월의 첫번째 N요일 조회
Object.defineProperty(Date.prototype, "getFirstDate", {
    value: function(_dowOffset) {
        var date = new Date(this);
        var firstDate = new Date(date.setDate(1));
        var day = firstDate.getDay();

        if (_dowOffset === undefined) {
            return firstDate;
        }
        else {
            var diff = _dowOffset < day ? _dowOffset + day : 1 + _dowOffset - day;
            return new Date(date.setDate(diff));
        }
    }
});

// Date 날짜 차이 조회
Object.defineProperty(Date.prototype, "getDiffDays", {
    value: function(target) {
        var date1 = new Date(this);
        var date2 = typeof target === "string" ? target.toDate() : new Date(target);
        var diff = null;
        var day = null;

        date1.setHours(0);
        date1.setMinutes(0);
        date1.setSeconds(0);
        date1.setMilliseconds(0);

        date2.setHours(0);
        date2.setMinutes(0);
        date2.setSeconds(0);
        date2.setMilliseconds(0);

        diff = Math.abs(date1.getTime() - date2.getTime());
        day = Math.floor(diff / (1000 * 3600 * 24));

        return day;
    }
});

// Date 날짜 차이 조회 (기준일 - 파라미터해서 음수까지 표현)
Object.defineProperty(Date.prototype, "getDiff", {
    value: function(target) {
        var date1 = new Date(this);
        var date2 = typeof target === "string" ? target.toDate() : new Date(target);
        var diff = null;
        var day = null;

        date1.setHours(0);
        date1.setMinutes(0);
        date1.setSeconds(0);
        date1.setMilliseconds(0);

        date2.setHours(0);
        date2.setMinutes(0);
        date2.setSeconds(0);
        date2.setMilliseconds(0);

        diff = date1.getTime() - date2.getTime();
        day = Math.floor(diff / (1000 * 3600 * 24));

        return day;
    }
});

// String comma number 포맷
Object.defineProperty(String.prototype, "toCommaNum", {
    value: function(unit) {
        var str = this.replace(/[^0-9.-]/g, "");
        var strSplit = str.split(".");

        if (str) {
            strSplit[0] = strSplit[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return strSplit.join(".") + (unit || "");
        }
        else {
            return this;
        }
    }
});

// String 전화번호 포맷
Object.defineProperty(String.prototype, "toTelNo", {
    value: function() {
        /**
         * \D - 숫자 제외 문자
         * \d - 숫자
         * \w - 문자
         * \S - 띄어쓰기가 아닌 값
         */
        var str = this.replace(/\D/g, "");

        if (str) {
            if (str.indexOf("02") === 0) {
                return str.replace(/(\S{2})(\S{3,4})(\S{4})/, "$1-$2-$3");
            }
            else {
                return str.replace(/(\S{3})(\S{3,4})(\S{4})/, "$1-$2-$3");
            }
        }
        else {
            return this;
        }
    }
});

// String 포맷
Object.defineProperty(String.prototype, "toFormat", {
    value: function(f) {
        var strIdx = 0;

        if (f) {
            return f.replace(/[#]/gi, () => {
                return this[strIdx++] || "";
            });
        }
        else {
            return this;
        }
    }
});

// String > Date 타입으로 변경
Object.defineProperty(String.prototype, "toDate", {
    value: function() {
        if (!this.valueOf()) { return null; }

        var date = new Date(
            this.slice(0, 4), // 년
            (this.slice(4, 6) || 1) - 1 , // 월
            this.slice(6, 8) || 1, // 일
            this.slice(8, 10) || 0, // 시
            this.slice(10, 12) || 0, // 분
            this.slice(12, 14) || 0 // 초
        );

        return date;
    }
});

// YYYYMMDD 에서 요일 명칭 조회
Object.defineProperty(String.prototype, "getDayName", {
    value: function(isLong) {
        var shortNames = [ "일", "월", "화", "수", "목", "금", "토" ];
        var longNames = [ "일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일" ];
        var date = new Date(
            this.slice(0, 4), // 년
            this.slice(4, 6) - 1, // 월
            this.slice(6, 8), // 일
            this.slice(8, 10), // 시
            this.slice(10, 12), // 분
            this.slice(12, 14) // 초
        );

        return isLong ? longNames[date.getDay()] : shortNames[date.getDay()];
    }
});

// String Text 변경
Object.defineProperty(String.prototype, "toCustomFormat", {
    value: function(f, p) {
        var str = this;
        var format = f || "";
        var pattern = p || "";

        // Type또는 Format이 없는 경우 기존 값 반환
        if (!format || !pattern) {
            return str;
        }

        switch (format) {
            case "string": case "s": // "12345".toCustomFormat("string", "##_###") >> 12_345
                var strCharIdx = 0;

                str = pattern.replace(/[#]/gi, function() {
                    return str[strCharIdx++] || "";
                });
                break;

            case "number": case "n": // "1000.1000".toCustomFormat("number", ",.0-2") >> 1,000.1
            case "percent": case "p": // "0.991000".toCustomFormat("percent", ".2") >> 99.10
                var opt = pattern.split(".");
                var isComma = opt[0] === ",";
                var digits = opt[1].split("-");
                var minDigits = Number(digits[0]) || 0;
                var maxDigits = Number(digits[1]) || minDigits;
                var pow = Math.pow(10, maxDigits);

                // 퍼센트 포맷인 경우 가중치 계산
                if (format === "percent" || format === "p") {
                    str = Number(str) * 100;
                }
                else {
                    str = Number(str);
                }

                // 소수점 처리
                str = Math.round(str * pow) / pow;

                // 콤마 처리
                if (isComma) {
                    str = str.toLocaleString("en-US", { minimumFractionDigits: minDigits, maximumFractionDigits: maxDigits });
                }
                else {
                    str = String(str);
                }
                break;

            case "date": case "d": // "999912312359".toCustomFormat("date", "####-##-## ##:##") >> 9999-12-31 23:59
                var charIdx = 0;

                /**
                 * 시간 오전, 오후
                 * Ex. "999912312359".toCustomFormat("date", "####-##-## AP ##:##") >> 9999-12-31 오후 11:59
                 */
                if (pattern.indexOf("AP") !== -1) {
                    var prefix = str.slice(0, 8); // 년월일
                    var time = Number(str.slice(8, 10)); // 시간
                    var suffix = str.slice(10); // 분초
                    var ap = time < 12 ? "오전" : "오후";

                    time = time % 12 ? time % 12 : 12;
                    str = prefix + String(time).padStart(2, "0") + suffix;
                    pattern = pattern.replace("AP", ap);
                }

                /**
                 * 년도 2자리 표기
                 * Ex. "999912312359".toCustomFormat("date", "##-##-## ##:##") >> 99-12-31 23:59
                 */
                if (pattern.indexOf("####") !== 0) {
                    str = str.slice(2);
                }

                str = pattern.replace(/[#]/gi, function() {
                    return str[charIdx++] || "";
                });
                break;

            case "time": case "t": // "2359".toCustomFormat("time", "##:##") >> 23:59
                var timeCharIdx = 0;

                /**
                 * 시간 오전, 오후
                 * Ex. "2359".toCustomFormat("time", "AP ##:##"") >> 오후 11:59
                 */
                if (pattern.indexOf("AP") !== -1) {
                    var hh = Number(str.slice(0, 2)); // 시간
                    var mm = str.slice(2); // 분초
                    var strAP = hh < 12 ? "오전" : "오후";

                    hh = hh % 12 ? hh % 12 : 12;
                    str = String(hh).padStart(2, "0") + mm;
                    pattern = pattern.replace("AP", strAP);
                }

                str = pattern.replace(/[#]/gi, function() {
                    return str[timeCharIdx++] || "";
                });
                break;

            case "file": case "f": // "663155".toCustomFormat("file", "KB") >> 647.6
                var sizes = ["Bytes", "KB", "MB", "GB"];
                var bytes = Number(str);
                var index = -1;

                if (pattern === "") {
                    if (bytes === 0) {
                        str =  0;
                    }
                    else {
                        index = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
                        str = bytes / Math.pow(1024, index);
                    }
                }
                else {
                    index = sizes.indexOf(pattern);
                    str = bytes / Math.pow(1024, index);
                }

                str = str.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
                break;

            default:
        }

        return str;
    }
});

// Number to Comma Number
Object.defineProperty(Number.prototype, "toCommaNum", {
    value: function() {
        var str = String(this).replace(/[^0-9.-]/g, "");
        var strSplit = str.split(".");
        strSplit[0] = strSplit[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");

        return strSplit.join(".");
    }
});

// Number padStart
Object.defineProperty(Number.prototype, "padStart", {
    value: function(targetLength, padString) {
        return this.toString().padStart(targetLength, padString);
    }
});

// Object Deep Copy with Array
Object.defineProperty(Object.prototype, "deepCopy", {
    value: function(prop) {
        if (Array.isArray(this)) {
            return Object.assign([], this, prop);
        }
        else {
            var obj = Object.assign({}, this);
            var override = function(legacy, p) {
                for (var k in p) {
                    if (Object.hasOwnProperty.call(p, k)) {
                        var v = p[k];

                        if (typeof v === "object" && !Array.isArray(v)) {
                            legacy[k] !== undefined && override(legacy[k], v);
                        }
                        else {
                            if (Array.isArray(v)) {
                                legacy[k] !== undefined && (legacy[k] = Object.assign([], legacy[k], v));
                            }
                            else {
                                legacy[k] !== undefined && (legacy[k] = v);
                            }
                        }
                    }
                }
            };

            if (typeof prop === "object") {
                override(obj, prop);
            }

            return obj;
        }
    }
});

// Array Object Sort
Object.defineProperty(Array.prototype, "objectSort", {
    value: function(key, orderBy) {
        if (!this.valueOf()) { return []; }

        return this.sort(function(a, b) {
            var order = orderBy && orderBy.toUpperCase() === "DESC" ? -1 : 1;
            var x = isNaN(a[key]) ? a[key].toUpperCase() : Number(a[key]);
            var y = isNaN(b[key]) ? b[key].toUpperCase() : Number(b[key]);

            return x > y ? order : x < y ? -order : 0;
        });
    }
});