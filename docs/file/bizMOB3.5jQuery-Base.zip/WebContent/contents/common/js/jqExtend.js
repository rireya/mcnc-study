/**
 * @author author
 * @title jquery extend + jquery preset event
 */

/** Extend Function */
$.keypad = function(callback) {
    // Input 영역 focus시 하단 정보 숨김 처리
    if (bizMOB.Device.isIOS()) {
        // 키패드 On
        $(document).on("focusin", "input[type='text'], input[type='tel'], input[type='number'], textarea", function(e) {
            var $target = $($(e.target));

            if (!$target.prop("readonly") && !$target.prop("disabled")) {
                callback && callback(true, e.target);
            }
        });

        // 키패드 Off
        $(document).on("focusout", "input[type='text'], input[type='tel'], input[type='number'], textarea", function(e) {
            var $target = $($(e.target));

            if (!$target.prop("readonly") && !$target.prop("disabled")) {
                callback && callback(false, e.target);
            }
        });
    }
    else {
        var h = $(window).height();

        // 키패드 올라온 경우 반응
        $(window).on("resize", function() {
            var isKeypad = $(window).height() !== h;

            callback && callback(isKeypad);
        });
    }
};

/** Sample */
$.fn.test = function() {
    console.log("test");
};

/** contains 대소문자 구분 안하는 선택자 추가 */
$.extend($.expr[":"], { "containsIN": function(elem, _, match) {
    return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0; }
});

/** jQuery preset event */
jQuery(function() {

});