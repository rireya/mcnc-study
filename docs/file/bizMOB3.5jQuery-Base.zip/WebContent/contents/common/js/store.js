/**
 * @author author
 * @title __namespace.store
 */

/** @namespace store - 전역 상수변수 관리 */
var __namespace = window.__namespace;

/**
 * Store Module
 */
__namespace.store = {
    /**
     * 앱 정보
     */
    APP: {
        EMUL: { // 에뮬레이터용 정보
            PACKAGE: "", // 패키지명 -- 에뮬레이터에서 확인할 앱 버전의 패키지 하드코딩
            APP_NAME: "", // 앱 이름
            DEVICE_ID: "emul_00000000-0000-0000-0000-000000000000", // 에뮬레이터용 디바이스 ID
        },
        DEV: { // 개발앱 정보
            PACKAGE: "", // 패키지명 -- 앱정보 판단용
            APP_NAME: "", // 앱 이름
        },
        QAS: { // 품질앱 정보
            PACKAGE: "", // 패키지명 -- 앱정보 판단용
            APP_NAME: "", // 앱 이름
        },
        PRD: { // 운영앱 정보
            PACKAGE: "", // 패키지명 -- 앱정보 판단용
            APP_NAME: "", // 앱 이름
        },
    },

    // App Key 조회 -- Native에 앱키 추가 필요
    getAppKey: function() {
        var deviceInfo = bizMOB.Device.getInfo();
        return deviceInfo.app_key;
    },

    // Package Name 조회 -- Native에 패키지명 추가 필요
    getPackageName: function() {
        var deviceInfo = bizMOB.Device.getInfo();
        return deviceInfo.model === "Emulator" ? this.APP.EMUL.PACKAGE : deviceInfo.package_name;
    },

    // App Type 조회 (EMUL: 에뮬레이터, DEV: 개발, QAS: 품질, PRD: 운영)
    getAppType: function() {
        var deviceInfo = bizMOB.Device.getInfo();
        var package = this.getPackageName();

        if (deviceInfo.model === "Emulator") {
            return "EMUL";
        }
        else {
            switch (package) {
                case this.APP.DEV.PACKAGE: return "DEV";
                case this.APP.QAS.PACKAGE: return "QAS";
                case this.APP.PRD.PACKAGE: return "PRD";
            }
        }
    },

    // App Name 조회
    getAppName: function() {
        var appType = this.getAppType();
        return this.APP[appType].APP_NAME;
    },

    // 개발앱 확인
    isDev: function() {
        var deviceInfo = bizMOB.Device.getInfo();
        return deviceInfo.package_name === this.APP.DEV.PACKAGE;
    },

    // 개발앱 확인
    isQas: function() {
        var deviceInfo = bizMOB.Device.getInfo();
        return deviceInfo.package_name === this.APP.QAS.PACKAGE;
    },

    // 개발앱 확인
    isPrd: function() {
        var deviceInfo = bizMOB.Device.getInfo();
        return deviceInfo.package_name === this.APP.PRD.PACKAGE;
    },

    /**
     * 권한 정보
     */
    AUTH: {

    },

    // 권한 코드 조회
    getAuthCode: function() {
        // TODO
    },

    /**
     * 파일 정보
     */
    FILE_PATH: {
        INTERNAL: "{internal}/",
        TEMP: "{temporary}/",
        DOWNLOAD: "{external}/Download/",
        CAMERA: "{temporary}/resource/camera/",
        RESIZE: "{temporary}/resource/resize", // 마지막에 "/" 없어야 됨
    },

    /**
     * 기타
     */
    SAMPLE: {
        TEMP: { code: "1", name: "샘플" },

    },

    findSampleItem: function(code) {
        return Object.values(this).filter(function(item) {
            return typeof item !== "function";
        }).find(function(item) {
            if (Object.hasOwnProperty.call(item, "code")) {
                return item.code === code;
            }
            else {
                return false;
            }
        });
    },
};