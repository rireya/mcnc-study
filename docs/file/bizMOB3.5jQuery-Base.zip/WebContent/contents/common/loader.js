(function() {
    var PATH_DEPTH = location.pathname.split("/");
    var PATH_LIST_IDX = PATH_DEPTH.length - 2;
    var RELATE_DEPTH = "";

    for (var i = PATH_LIST_IDX; i > 0; i--) {
        if (PATH_DEPTH[i] != "contents") {
            RELATE_DEPTH += "../";
        }
        else {
            break;
        }
    }

    var polyfill = [
        // Custom Polyfill
        "common/polyfill/customPolyfill/custom-polyfill.js",

        // es6-promise Polyfill
        "common/polyfill/es6Promise/es6-promise.min.js",
        "common/polyfill/es6Promise/es6-promise.auto.min.js",

        // intersection-observer Polyfill
        "common/polyfill/intersectionObserver/intersection-observer.min.js"
    ];

    var define = {
        // (샘플) Datepicker
        datepicker: [
            "common/libs/air-datepicker/datepicker.css",
            "common/libs/air-datepicker/datepicker.js",
        ],
    };

    var importUrls = [];
    var importStr = "";
    var getDefines = function() {
        var script = document.getElementsByTagName("script");
        // eslint-disable-next-line no-useless-escape
        var defines = script[script.length-1].src.replace(/^[^\?]+\?/, "").replace(/#.+$/, "").split("&");
        var queries = {};
        var query;

        while (defines.length) {
            query = defines.shift().split("=");
            queries[query[0]] = query[1];
        }

        if (Object.prototype.hasOwnProperty.call(queries, "define")) {
            return queries.define.split(",").map(function(item) {
                return item.replace(/%20/gi, ""); // 띄어쓰기 제거
            });
        }
        else {
            return [];
        }
    };

    // jQuery 우선순위로 추가
    importUrls.push("bizMOB/jquery-3.4.1.min.js");

    // Default 라이브러리 추가
    importUrls = importUrls.concat(polyfill);

    // define된 라이브러리 추가
    getDefines().forEach(function(key) {
        if (key) { importUrls = importUrls.concat(define[key]); }
    });

    // 기본 파일 추가
    var folderName = location.pathname.split("contents/")[1].split("/")[0];
    importUrls = importUrls.concat([
        // CSS
        "common/css/common.css",
        folderName + "/css/" + folderName.toUpperCase() + ".css", // toUpperCase, toLowerCase

        // bizMOB
        "bizMOB/bizMOB-core.js",
        "bizMOB/bizMOB-xross3.js",
        "bizMOB/bizMOB-util3.js",
        "bizMOB/bizMOB-multilayout3.js",

        // common
        "common/js/common.js",
        // "common/js/html.js",
        // "common/js/prototype.js",

        // "common/js/storage.js",
        // "common/js/store.js",

        // "common/js/jqExtend.js",

        // "common/js/request.js",
        // "common/js/native.js",
        // "common/js/preload.js",

        // View File
        location.pathname.split("contents/")[1].replace(/html/g, "js"),
    ]);

    importUrls.forEach(function(url) {
        var type = url.split(".").pop();

        switch (type) {
            case "js": {
                importStr += "<script type=\"text/javascript\" src=\"" + RELATE_DEPTH + url + "\" charset=\"utf-8\"></script>\n";
                break;
            }

            case "css": {
                importStr += "<link type=\"text/css\" rel=\"stylesheet\" href=\"" + RELATE_DEPTH + url + "\"/>\n";
            }
        }
    });

    document.write(importStr);
})();