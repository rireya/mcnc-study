/**
 * @author author
 * @title common module code
 */

/** @namespace common */
var __namespace = {};

/**
 * View Module
 */
__namespace.view = (function() {
    var view = {};

    // A private function.
    function privateFunction() {
        return "This is a private function";
    }

    // A public function.
    view.publicFunction = function() {
        console.log(privateFunction());

        return "This is a public function";
    };

    // A public class.
    view.publicClass = class {
        constructor() {
            this.message = "This is a public class";
        }

        displayMessage() {
            console.log(this.message);
        }
    };

    // Return module
    return view;
})();

/**
 * Message Module
 */
__namespace.msg = (function() {
    var msg = {};

    // Return module
    return msg;
})();

/**
 * Async Module
 */
__namespace.async = (function() {
    var async = {};

    // Return module
    return async;
})();

/**
 * Request Module
 */
__namespace.req = (function() {
    var req = {};

    function toHeader(header) {
        // TODO 헤더 선처리
        return header || {};
    }

    function toBody(body) {
        // TODO Body 선처리
        return body || {};
    }

    function toResponse(tr) {
        var response = {
            ok: true,
            code: "",
            message: "",
            json: tr
        };

        // 응답 전문 데이터 구조 오류
        if (typeof tr !== "object" || tr === null || tr.header === undefined) {
            response.ok = false;
            response.code = "ERROR";
            response.message = "알 수 없는 오류입니다."
        }
        // 긴급 업데이트 처리
        else if (tr.header.content_update_flag && tr.header.emergency_flag) {
            response.ok = false;
            response.code = "EXCEPTION";
            response.message = "컨텐츠가 새 버전으로 변경되었습니다.";
        }
        // 일반적 오류
        else if (!tr.header.result) {
            response.ok = false;

            switch (tr.header.error_code) {
                case "HE0404":
                case "HE0503":
                case "NE0001":
                case "CE0001":
                    response.code = "ERROR";
                    response.message = "서버에 연결할 수 없습니다.";
                    break;

                case "NE0002":
                case "NE0003":
                    response.code = "ERROR";
                    response.message = "네트워크 상태가 좋지 않습니다.\n잠시후 다시 시도해 주세요.";
                    break;

                case "ERR000": // 세션 끊김
                    response.code = "ERROR";
                    response.message = "장기간 미사용으로 접속이 끊어졌습니다.\n다시 로그인하시기 바랍니다.";
                    break;

                default:
                    response.code = tr.header.error_code || "ERROR";
                    response.message = tr.header.error_text || "서버 연결 상태가 좋지 않습니다.\n잠시후 다시 시도해 주세요.";
                    break;
            }
        }

        return response;
    }

    function request(options) {
        // TODO
    }

    /**
     *
     * @param {string} trcode - Trcode
     * @param {object} option - 요청 정보
     * @param {object} option.body - 요청 Body 정보
     * @param {object} [option.header] - 요청 Header 정보
     * @param {boolean} [option.mock=false] - mock 데이터 요청 여부
     * @param {boolean} [option.progress=true] - progress 노출 여부
     * @param {function} successCallback - 성공 Callback
     * @param {function} [errorCallback=null] - 실패 Callback (값이 없는 경우 일반 메시지 처리)
     */
    req.fetch = function(trcode, option, successCallback, errorCallback) {
        request({
            trcode: trcode,
            header: toHeader(option.header),
            body: toBody(option.body),
            progressEnable: Object.hasOwnProperty.call(option, "progress") ? option.progress : true,
            mock: Object.hasOwnProperty.call(option, "mock") ? option.mock : false,
            callback: function(response) {
                if (response.ok) {
                    successCallback(response.json.body);
                }
                else {
                    // 에러는 서버의 에러코드와 메시지를 기본으로 출력. 네이티브 에러는 따로 처리한걸 보여줘야됨
                    switch (response.code) {
                        case "EXCEPTION": // 앱 재시작 처리 -- bizMOB.App.exit({ _sType: "restart" });
                            // TODO 메시지 노출 처리
                            break;

                        case "ERROR": // 네이티브 통신 에러
                            // TODO 메시지 노출 처리
                            break;

                        default: // 기본 오류처리
                            if (errorCallback) {
                                errorCallback(response.code, response.message);
                            }
                            else {
                                // TODO 메시지 노출 처리
                            }
                            break;
                    }
                }
            }
        });
    };

    // Return module
    return req;
})();

/**
 * Progress Module
 */
__namespace.progress = (function() {
    var progress = {};

    // Return module
    return progress;
})();

/**
 * Layout Module
 */
__namespace.layout = (function() {
    var layout = {};

    // Return module
    return layout;
})();

/**
 * Push Module
 */
__namespace.push = (function() {
    var push = {};

    // Return module
    return push;
})();

/**
 * Plugin Module
 */
__namespace.plugin = (function() {
    var plugin = {};

    // Return module
    return plugin;
})();

// Attach MyModule to the window object
window.__namespace = __namespace;