/**
 * @author author
 * @title util module code
 */

/** @namespace util */
var __namespace = window.__namespace;

/**
 * Util Module
 */
__namespace.util = (function() {
    var util = {};

    // A private function.
    function privateFunction() {
        return "This is a private function";
    }

    // A public function.
    util.publicFunction = function() {
        console.log(privateFunction());

        return "This is a public function";
    };

    // A public class.
    util.publicClass = class {
        constructor() {
            this.message = "This is a public class";
        }

        displayMessage() {
            console.log(this.message);
        }
    };

    // Return module
    return util;
})();