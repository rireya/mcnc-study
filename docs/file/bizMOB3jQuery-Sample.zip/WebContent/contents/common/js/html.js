/**
 * @author author
 * @title html template code
 */

/** @namespace html - html template 관리 */
var __namespace = window.__namespace;

/* eslint-disable quotes */
/**
 * Html Template
 */
__namespace.html = {
    /** Alert Html */
    alert: '' +
    '<div>' +
    '</div>',

    /** Confirm Html */
    confirm: '',

    /** Submit 프로그레스 */
    submitProgress: '',
};