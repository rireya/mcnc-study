/**
 * @author author
 * @title __namespace.storage
 */

/** @namespace storage - 전역 local storage 데이터 관리 */
var __namespace = window.__namespace;

/**
 * Storage Module
 */
__namespace.storage = {
    /**
    * 속성 변경 함수.
    * storage.temp.name = "foo" => storage.changeProp("temp", { name: "foo" }).
    * storage.temp.auth.a = true => storage.changeProp("temp", { auth: { a: true }}).
    * @param {string} key - 속성을 변경한 변수명 (Ex. storage.temp 인 경우, "temp")
    * @param {object} prop - 변경할 속성의 key-value (Ex. storage.temp.name = "foo" 인 경우, { name: "foo" })
    * @returns 변경된 storage value
    */
    modifyProp: function(key, prop) {
        var data = this[key];
        /**
         *
         * @param {object} legacy - 이전 데이터
         * @param {object} p - 변경할 데이터
         */
        var override = function(legacy, p) {
            for (var k in p) {
                if (Object.hasOwnProperty.call(p, k)) {
                    var v = p[k];

                    if (v instanceof Object && !Array.isArray(v)) {
                        legacy[k] !== undefined && override(legacy[k], v);
                    }
                    else {
                        legacy[k] !== undefined && (legacy[k] = v);
                    }
                }
            }
        };

        if (data instanceof Object && prop instanceof Object) {
            override(data, prop);
        }

        this[key] = data;

        return data;
    },

    /** Storage */
    get storage() {
        var key = arguments.callee.name.split(" ").pop();
        var item = bizMOB.Storage.get({ _sKey: key }) || undefined;

        return item;
    },
    set storage(value) {
        var key = arguments.callee.name.split(" ").pop();

        if (value) {
            bizMOB.Storage.set({ _sKey: key, _vValue: value });
        }
        else {
            bizMOB.Storage.remove({ _sKey: key });
        }
    },

    /** PROPERTIES */
    get PROPERTIES() {
        var key = arguments.callee.name.split(" ").pop();
        var item = bizMOB.Properties.get({ _sKey: key }) || undefined;

        return item;
    },
    set PROPERTIES(value) {
        var key = arguments.callee.name.split(" ").pop();

        if (value) {
            bizMOB.Properties.set({ _sKey: key, _vValue: value });
        }
        else {
            bizMOB.Properties.remove({ _sKey: key });
        }
    }
};