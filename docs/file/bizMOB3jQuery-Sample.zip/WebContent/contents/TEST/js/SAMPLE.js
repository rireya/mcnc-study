/**
 * @author author
 * @pages [ pages ]
 * @title title
 */

// bizMOB.addEvent("backbutton", "page.backbutton"); // common.js에서 page.backbutton 존재시 백버튼 이벤트 바인딩
bizMOB.addEvent("resume", "page.resume"); // 페이지(웹뷰)가 활성화 되었을 때(= focus가 맞추어졌을때, 화면상으로 드러났을때)
bizMOB.addEvent("beforeready", "page.beforeready"); // 페이지(웹뷰)가 로드되기 전
bizMOB.addEvent("ready", "page.ready"); // 페이지(웹뷰)가 로드되었을 때

/** @type {bizMobRoot} */
var page = {

    // Page Open시 전달받은 데이터
    props: {
        foo: "", // String: "", Number: 0, Array: [], Object: {}, Boolean: false
    },

    // Page 상태관리 데이터
    state: {
        foo: "", // String: "", Number: 0, Array: [], Object: {}, Boolean: false
    },

    // Page Entry Point
    init: function(event) {
        // 전달받은 데이터 저장
        page.props = $.extend(true, page.props, event.data);

        // 화면 레이아웃 관련 정의
        page.initLayout();

        // 이벤트 정의
        page.initInterface();

        // 초기 화면 데이터 설정
        page.initData(page.props);
    },


    /*****************************/
    /***** index: Layout *********/
    /*****************************/

    // 레이아웃 설정
    initLayout: function() {
        var date = new Date();
    },


    /*****************************/
    /***** index: Data ***********/
    /*****************************/

    // 초기 화면 데이터 처리 설정
    initData: function(props) {
        // 1
        page.reqGetMock({
            body: {

            }
        }, function(body) {
            // callback
        });

        // 2
        page.reqPostMock({
            body: {

            }
        }, function(body) {
            // callback
        }, function(code, msg) {
            // error
        });
    },


    /*****************************/
    /***** index: Event **********/
    /*****************************/

    // 화면 이벤트 설정
    initInterface: function() {
        $("#loading")[0].observer(function(handler) {
            page.reqGetMock({
                body: {

                }
            }, function(body) {
                var isEof = false;

                if (!isEof) {
                    handler.on();
                }
                else {
                    handler.hide();
                }
            });
        });
    },


    /*****************************/
    /***** index: Element Set ****/
    /*****************************/

    /**
     * set html element
     */
    setInput: function(value) {

    },


    /*****************************/
    /***** index: Render *********/
    /*****************************/

    // render html
    renderList: function(list) {

    },


    /*****************************/
    /***** index: Request ********/
    /*****************************/

    // get request
    reqGetMock: function(option, callback) {
        option.mock = true;

        // 전문
        __namespace.req.fetch("TST0002", option, callback);
    },

    // post request
    reqPostMock: function(option, callback, errorCallback) {
        option.progress = false;

        // 전문
        __namespace.req.fetch("TST0002", option, callback, errorCallback);
    },

    // put request
    reqPutMock: function(option, callback) {
        __namespace.req.fetch("TST0003", option, callback, function(code, msg) {
            // TODO
        });
    },


    /*****************************/
    /***** index: Etc. ***********/
    /*****************************/

};