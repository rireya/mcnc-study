/**
 * @author author
 * @pages [ TEST0000 ]
 * @title TEST0000
 */

/** @type {bizMobRoot} */
var page = {
    init: function(event) {
        console.log(event);
        page.test();
    },

    test: function() {
        console.log("test");
        return "TEST";
    },

    call0: function() {

    }
};